// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int actionBarDivider = 0x7f010047;
    public static final int actionBarItemBackground = 0x7f010048;
    public static final int actionBarSize = 0x7f010046;
    public static final int actionBarSplitStyle = 0x7f010044;
    public static final int actionBarStyle = 0x7f010043;
    public static final int actionBarTabBarStyle = 0x7f010040;
    public static final int actionBarTabStyle = 0x7f01003f;
    public static final int actionBarTabTextStyle = 0x7f010041;
    public static final int actionBarWidgetTheme = 0x7f010045;
    public static final int actionButtonStyle = 0x7f010073;
    public static final int actionDropDownStyle = 0x7f010072;
    public static final int actionMenuTextAppearance = 0x7f010049;
    public static final int actionMenuTextColor = 0x7f01004a;
    public static final int actionModeBackground = 0x7f01004d;
    public static final int actionModeCloseButtonStyle = 0x7f01004c;
    public static final int actionModeCloseDrawable = 0x7f01004f;
    public static final int actionModePopupWindowStyle = 0x7f010051;
    public static final int actionModeShareDrawable = 0x7f010050;
    public static final int actionModeSplitBackground = 0x7f01004e;
    public static final int actionModeStyle = 0x7f01004b;
    public static final int actionOverflowButtonStyle = 0x7f010042;
    public static final int actionSpinnerItemStyle = 0x7f010078;
    public static final int activatedBackgroundIndicator = 0x7f010080;
    public static final int activityChooserViewStyle = 0x7f01007f;
    public static final int background = 0x7f01003b;
    public static final int backgroundSplit = 0x7f01003c;
    public static final int backgroundStacked = 0x7f010087;
    public static final int buttonStyleSmall = 0x7f010052;
    public static final int customNavigationLayout = 0x7f010088;
    public static final int displayOptions = 0x7f010082;
    public static final int divider = 0x7f01003e;
    public static final int dividerVertical = 0x7f010071;
    public static final int dropDownListViewStyle = 0x7f010075;
    public static final int dropdownListPreferredItemHeight = 0x7f010077;
    public static final int expandActivityOverflowButtonDrawable = 0x7f010097;
    public static final int headerBackground = 0x7f010091;
    public static final int height = 0x7f01003d;
    public static final int homeAsUpIndicator = 0x7f010074;
    public static final int homeLayout = 0x7f010089;
    public static final int horizontalDivider = 0x7f01008f;
    public static final int icon = 0x7f010085;
    public static final int iconifiedByDefault = 0x7f010098;
    public static final int indeterminateProgressStyle = 0x7f01008b;
    public static final int initialActivityCount = 0x7f010096;
    public static final int itemBackground = 0x7f010092;
    public static final int itemIconDisabledAlpha = 0x7f010094;
    public static final int itemPadding = 0x7f01008d;
    public static final int itemTextAppearance = 0x7f01008e;
    public static final int listPopupWindowStyle = 0x7f01007e;
    public static final int listPreferredItemHeightSmall = 0x7f01006b;
    public static final int listPreferredItemPaddingLeft = 0x7f01006c;
    public static final int listPreferredItemPaddingRight = 0x7f01006d;
    public static final int logo = 0x7f010086;
    public static final int navigationMode = 0x7f010081;
    public static final int popupMenuStyle = 0x7f010076;
    public static final int preserveIconSpacing = 0x7f010095;
    public static final int progressBarPadding = 0x7f01008c;
    public static final int progressBarStyle = 0x7f01008a;
    public static final int queryHint = 0x7f010099;
    public static final int searchAutoCompleteTextView = 0x7f01005d;
    public static final int searchDropdownBackground = 0x7f01005e;
    public static final int searchResultListItemHeight = 0x7f010068;
    public static final int searchViewCloseIcon = 0x7f01005f;
    public static final int searchViewEditQuery = 0x7f010063;
    public static final int searchViewEditQueryBackground = 0x7f010064;
    public static final int searchViewGoIcon = 0x7f010060;
    public static final int searchViewSearchIcon = 0x7f010061;
    public static final int searchViewTextField = 0x7f010065;
    public static final int searchViewTextFieldRight = 0x7f010066;
    public static final int searchViewVoiceIcon = 0x7f010062;
    public static final int selectableItemBackground = 0x7f010053;
    public static final int spinnerDropDownItemStyle = 0x7f01005c;
    public static final int spinnerItemStyle = 0x7f01005b;
    public static final int subtitle = 0x7f010084;
    public static final int subtitleTextStyle = 0x7f01003a;
    public static final int textAppearanceLargePopupMenu = 0x7f010055;
    public static final int textAppearanceListItemSmall = 0x7f01006e;
    public static final int textAppearanceSearchResultSubtitle = 0x7f01006a;
    public static final int textAppearanceSearchResultTitle = 0x7f010069;
    public static final int textAppearanceSmall = 0x7f010057;
    public static final int textAppearanceSmallPopupMenu = 0x7f010056;
    public static final int textColorPrimary = 0x7f010058;
    public static final int textColorPrimaryDisableOnly = 0x7f010059;
    public static final int textColorPrimaryInverse = 0x7f01005a;
    public static final int textColorSearchUrl = 0x7f010067;
    public static final int title = 0x7f010083;
    public static final int titleTextStyle = 0x7f010039;
    public static final int verticalDivider = 0x7f010090;
    public static final int windowActionBar = 0x7f01007a;
    public static final int windowActionBarOverlay = 0x7f01007b;
    public static final int windowActionModeOverlay = 0x7f01007c;
    public static final int windowAnimationStyle = 0x7f010093;
    public static final int windowContentOverlay = 0x7f010054;
    public static final int windowMinWidthMajor = 0x7f01006f;
    public static final int windowMinWidthMinor = 0x7f010070;
    public static final int windowNoTitle = 0x7f010079;
    public static final int windowSplitActionBar = 0x7f01007d;

    public ()
    {
    }
}
