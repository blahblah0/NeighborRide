// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__action_bar = 0x7f0c006b;
    public static final int abs__action_bar_container = 0x7f0c006a;
    public static final int abs__action_bar_subtitle = 0x7f0c005a;
    public static final int abs__action_bar_title = 0x7f0c0059;
    public static final int abs__action_context_bar = 0x7f0c006c;
    public static final int abs__action_menu_divider = 0x7f0c0002;
    public static final int abs__action_menu_presenter = 0x7f0c0003;
    public static final int abs__action_mode_bar = 0x7f0c006f;
    public static final int abs__action_mode_bar_stub = 0x7f0c006e;
    public static final int abs__action_mode_close_button = 0x7f0c005d;
    public static final int abs__activity_chooser_view_content = 0x7f0c005e;
    public static final int abs__checkbox = 0x7f0c0067;
    public static final int abs__content = 0x7f0c0066;
    public static final int abs__default_activity_button = 0x7f0c0061;
    public static final int abs__expand_activities_button = 0x7f0c005f;
    public static final int abs__home = 0x7f0c0000;
    public static final int abs__icon = 0x7f0c0063;
    public static final int abs__image = 0x7f0c0060;
    public static final int abs__imageButton = 0x7f0c005b;
    public static final int abs__list_item = 0x7f0c0062;
    public static final int abs__progress_circular = 0x7f0c0004;
    public static final int abs__progress_horizontal = 0x7f0c0005;
    public static final int abs__radio = 0x7f0c0069;
    public static final int abs__search_badge = 0x7f0c0072;
    public static final int abs__search_bar = 0x7f0c0071;
    public static final int abs__search_button = 0x7f0c0073;
    public static final int abs__search_close_btn = 0x7f0c0078;
    public static final int abs__search_edit_frame = 0x7f0c0074;
    public static final int abs__search_go_btn = 0x7f0c007a;
    public static final int abs__search_mag_icon = 0x7f0c0075;
    public static final int abs__search_plate = 0x7f0c0076;
    public static final int abs__search_src_text = 0x7f0c0077;
    public static final int abs__search_voice_btn = 0x7f0c007b;
    public static final int abs__shortcut = 0x7f0c0068;
    public static final int abs__split_action_bar = 0x7f0c006d;
    public static final int abs__submit_area = 0x7f0c0079;
    public static final int abs__textButton = 0x7f0c005c;
    public static final int abs__title = 0x7f0c0064;
    public static final int abs__titleDivider = 0x7f0c0065;
    public static final int abs__up = 0x7f0c0001;
    public static final int disableHome = 0x7f0c0036;
    public static final int edit_query = 0x7f0c0070;
    public static final int homeAsUp = 0x7f0c0037;
    public static final int listMode = 0x7f0c0034;
    public static final int normal = 0x7f0c0010;
    public static final int showCustom = 0x7f0c0038;
    public static final int showHome = 0x7f0c0039;
    public static final int showTitle = 0x7f0c003a;
    public static final int tabMode = 0x7f0c0035;
    public static final int useLogo = 0x7f0c003b;
    public static final int wrap_content = 0x7f0c001b;

    public ()
    {
    }
}
