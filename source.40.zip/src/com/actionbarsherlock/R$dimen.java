// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__action_bar_default_height = 0x7f0a0002;
    public static final int abs__action_bar_icon_vertical_padding = 0x7f0a0003;
    public static final int abs__action_bar_subtitle_bottom_margin = 0x7f0a0007;
    public static final int abs__action_bar_subtitle_text_size = 0x7f0a0005;
    public static final int abs__action_bar_subtitle_top_margin = 0x7f0a0006;
    public static final int abs__action_bar_title_text_size = 0x7f0a0004;
    public static final int abs__action_button_min_width = 0x7f0a0008;
    public static final int abs__alert_dialog_title_height = 0x7f0a0009;
    public static final int abs__config_prefDialogWidth = 0x7f0a0001;
    public static final int abs__dialog_min_width_major = 0x7f0a000a;
    public static final int abs__dialog_min_width_minor = 0x7f0a000b;
    public static final int abs__dropdownitem_icon_width = 0x7f0a000e;
    public static final int abs__dropdownitem_text_padding_left = 0x7f0a000c;
    public static final int abs__dropdownitem_text_padding_right = 0x7f0a000d;
    public static final int abs__search_view_preferred_width = 0x7f0a0010;
    public static final int abs__search_view_text_min_width = 0x7f0a000f;
    public static final int action_button_min_width = 0x7f0a0011;

    public ()
    {
    }
}
