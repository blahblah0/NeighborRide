// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int DialogWindowTitle_Sherlock = 0x7f09003a;
    public static final int DialogWindowTitle_Sherlock_Light = 0x7f09003b;
    public static final int Sherlock___TextAppearance_Small = 0x7f09004e;
    public static final int Sherlock___Theme = 0x7f090052;
    public static final int Sherlock___Theme_DarkActionBar = 0x7f090054;
    public static final int Sherlock___Theme_Dialog = 0x7f090055;
    public static final int Sherlock___Theme_Light = 0x7f090053;
    public static final int Sherlock___Widget_ActionBar = 0x7f090005;
    public static final int Sherlock___Widget_ActionMode = 0x7f09001a;
    public static final int Sherlock___Widget_ActivityChooserView = 0x7f090022;
    public static final int Sherlock___Widget_Holo_DropDownItem = 0x7f09002d;
    public static final int Sherlock___Widget_Holo_ListView = 0x7f09002a;
    public static final int Sherlock___Widget_Holo_Spinner = 0x7f090027;
    public static final int Sherlock___Widget_SearchAutoCompleteTextView = 0x7f090037;
    public static final int TextAppearance_Sherlock_DialogWindowTitle = 0x7f09004c;
    public static final int TextAppearance_Sherlock_Light_DialogWindowTitle = 0x7f09004d;
    public static final int TextAppearance_Sherlock_Light_Small = 0x7f090050;
    public static final int TextAppearance_Sherlock_Light_Widget_PopupMenu_Large = 0x7f090047;
    public static final int TextAppearance_Sherlock_Light_Widget_PopupMenu_Small = 0x7f090049;
    public static final int TextAppearance_Sherlock_Small = 0x7f09004f;
    public static final int TextAppearance_Sherlock_Widget_ActionBar_Menu = 0x7f09003c;
    public static final int TextAppearance_Sherlock_Widget_ActionBar_Subtitle = 0x7f09003f;
    public static final int TextAppearance_Sherlock_Widget_ActionBar_Subtitle_Inverse = 0x7f090040;
    public static final int TextAppearance_Sherlock_Widget_ActionBar_Title = 0x7f09003d;
    public static final int TextAppearance_Sherlock_Widget_ActionBar_Title_Inverse = 0x7f09003e;
    public static final int TextAppearance_Sherlock_Widget_ActionMode_Subtitle = 0x7f090043;
    public static final int TextAppearance_Sherlock_Widget_ActionMode_Subtitle_Inverse = 0x7f090044;
    public static final int TextAppearance_Sherlock_Widget_ActionMode_Title = 0x7f090041;
    public static final int TextAppearance_Sherlock_Widget_ActionMode_Title_Inverse = 0x7f090042;
    public static final int TextAppearance_Sherlock_Widget_DropDownHint = 0x7f090051;
    public static final int TextAppearance_Sherlock_Widget_DropDownItem = 0x7f09004b;
    public static final int TextAppearance_Sherlock_Widget_PopupMenu = 0x7f090045;
    public static final int TextAppearance_Sherlock_Widget_PopupMenu_Large = 0x7f090046;
    public static final int TextAppearance_Sherlock_Widget_PopupMenu_Small = 0x7f090048;
    public static final int TextAppearance_Sherlock_Widget_TextView_SpinnerItem = 0x7f09004a;
    public static final int Theme_Sherlock = 0x7f090056;
    public static final int Theme_Sherlock_Dialog = 0x7f09005b;
    public static final int Theme_Sherlock_Light = 0x7f090057;
    public static final int Theme_Sherlock_Light_DarkActionBar = 0x7f090058;
    public static final int Theme_Sherlock_Light_Dialog = 0x7f09005c;
    public static final int Theme_Sherlock_Light_NoActionBar = 0x7f09005a;
    public static final int Theme_Sherlock_NoActionBar = 0x7f090059;
    public static final int Widget = 0x7f090004;
    public static final int Widget_Sherlock_ActionBar = 0x7f090006;
    public static final int Widget_Sherlock_ActionBar_Solid = 0x7f090007;
    public static final int Widget_Sherlock_ActionBar_TabBar = 0x7f09000e;
    public static final int Widget_Sherlock_ActionBar_TabText = 0x7f090011;
    public static final int Widget_Sherlock_ActionBar_TabView = 0x7f09000b;
    public static final int Widget_Sherlock_ActionButton = 0x7f090014;
    public static final int Widget_Sherlock_ActionButton_CloseMode = 0x7f090016;
    public static final int Widget_Sherlock_ActionButton_Overflow = 0x7f090018;
    public static final int Widget_Sherlock_ActionMode = 0x7f09001b;
    public static final int Widget_Sherlock_ActivityChooserView = 0x7f090023;
    public static final int Widget_Sherlock_Button_Small = 0x7f090025;
    public static final int Widget_Sherlock_DropDownItem_Spinner = 0x7f09002e;
    public static final int Widget_Sherlock_Light_ActionBar = 0x7f090008;
    public static final int Widget_Sherlock_Light_ActionBar_Solid = 0x7f090009;
    public static final int Widget_Sherlock_Light_ActionBar_Solid_Inverse = 0x7f09000a;
    public static final int Widget_Sherlock_Light_ActionBar_TabBar = 0x7f09000f;
    public static final int Widget_Sherlock_Light_ActionBar_TabBar_Inverse = 0x7f090010;
    public static final int Widget_Sherlock_Light_ActionBar_TabText = 0x7f090012;
    public static final int Widget_Sherlock_Light_ActionBar_TabText_Inverse = 0x7f090013;
    public static final int Widget_Sherlock_Light_ActionBar_TabView = 0x7f09000c;
    public static final int Widget_Sherlock_Light_ActionBar_TabView_Inverse = 0x7f09000d;
    public static final int Widget_Sherlock_Light_ActionButton = 0x7f090015;
    public static final int Widget_Sherlock_Light_ActionButton_CloseMode = 0x7f090017;
    public static final int Widget_Sherlock_Light_ActionButton_Overflow = 0x7f090019;
    public static final int Widget_Sherlock_Light_ActionMode = 0x7f09001c;
    public static final int Widget_Sherlock_Light_ActionMode_Inverse = 0x7f09001d;
    public static final int Widget_Sherlock_Light_ActivityChooserView = 0x7f090024;
    public static final int Widget_Sherlock_Light_Button_Small = 0x7f090026;
    public static final int Widget_Sherlock_Light_DropDownItem_Spinner = 0x7f09002f;
    public static final int Widget_Sherlock_Light_ListPopupWindow = 0x7f09001f;
    public static final int Widget_Sherlock_Light_ListView_DropDown = 0x7f09002c;
    public static final int Widget_Sherlock_Light_PopupMenu = 0x7f090021;
    public static final int Widget_Sherlock_Light_PopupWindow_ActionMode = 0x7f090031;
    public static final int Widget_Sherlock_Light_ProgressBar = 0x7f090033;
    public static final int Widget_Sherlock_Light_ProgressBar_Horizontal = 0x7f090035;
    public static final int Widget_Sherlock_Light_SearchAutoCompleteTextView = 0x7f090039;
    public static final int Widget_Sherlock_Light_Spinner_DropDown_ActionBar = 0x7f090029;
    public static final int Widget_Sherlock_ListPopupWindow = 0x7f09001e;
    public static final int Widget_Sherlock_ListView_DropDown = 0x7f09002b;
    public static final int Widget_Sherlock_PopupMenu = 0x7f090020;
    public static final int Widget_Sherlock_PopupWindow_ActionMode = 0x7f090030;
    public static final int Widget_Sherlock_ProgressBar = 0x7f090032;
    public static final int Widget_Sherlock_ProgressBar_Horizontal = 0x7f090034;
    public static final int Widget_Sherlock_SearchAutoCompleteTextView = 0x7f090038;
    public static final int Widget_Sherlock_Spinner_DropDown_ActionBar = 0x7f090028;
    public static final int Widget_Sherlock_TextView_SpinnerItem = 0x7f090036;

    public ()
    {
    }
}
