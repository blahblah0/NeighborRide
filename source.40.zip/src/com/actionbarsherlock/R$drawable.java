// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__ab_bottom_solid_dark_holo = 0x7f020000;
    public static final int abs__ab_bottom_solid_inverse_holo = 0x7f020001;
    public static final int abs__ab_bottom_solid_light_holo = 0x7f020002;
    public static final int abs__ab_bottom_transparent_dark_holo = 0x7f020003;
    public static final int abs__ab_bottom_transparent_light_holo = 0x7f020004;
    public static final int abs__ab_share_pack_holo_dark = 0x7f020005;
    public static final int abs__ab_share_pack_holo_light = 0x7f020006;
    public static final int abs__ab_solid_dark_holo = 0x7f020007;
    public static final int abs__ab_solid_light_holo = 0x7f020008;
    public static final int abs__ab_solid_shadow_holo = 0x7f020009;
    public static final int abs__ab_stacked_solid_dark_holo = 0x7f02000a;
    public static final int abs__ab_stacked_solid_light_holo = 0x7f02000b;
    public static final int abs__ab_stacked_transparent_dark_holo = 0x7f02000c;
    public static final int abs__ab_stacked_transparent_light_holo = 0x7f02000d;
    public static final int abs__ab_transparent_dark_holo = 0x7f02000e;
    public static final int abs__ab_transparent_light_holo = 0x7f02000f;
    public static final int abs__activated_background_holo_dark = 0x7f020010;
    public static final int abs__activated_background_holo_light = 0x7f020011;
    public static final int abs__btn_cab_done_default_holo_dark = 0x7f020012;
    public static final int abs__btn_cab_done_default_holo_light = 0x7f020013;
    public static final int abs__btn_cab_done_focused_holo_dark = 0x7f020014;
    public static final int abs__btn_cab_done_focused_holo_light = 0x7f020015;
    public static final int abs__btn_cab_done_holo_dark = 0x7f020016;
    public static final int abs__btn_cab_done_holo_light = 0x7f020017;
    public static final int abs__btn_cab_done_pressed_holo_dark = 0x7f020018;
    public static final int abs__btn_cab_done_pressed_holo_light = 0x7f020019;
    public static final int abs__cab_background_bottom_holo_dark = 0x7f02001a;
    public static final int abs__cab_background_bottom_holo_light = 0x7f02001b;
    public static final int abs__cab_background_top_holo_dark = 0x7f02001c;
    public static final int abs__cab_background_top_holo_light = 0x7f02001d;
    public static final int abs__dialog_full_holo_dark = 0x7f02001e;
    public static final int abs__dialog_full_holo_light = 0x7f02001f;
    public static final int abs__ic_ab_back_holo_dark = 0x7f020020;
    public static final int abs__ic_ab_back_holo_light = 0x7f020021;
    public static final int abs__ic_cab_done_holo_dark = 0x7f020022;
    public static final int abs__ic_cab_done_holo_light = 0x7f020023;
    public static final int abs__ic_clear = 0x7f020024;
    public static final int abs__ic_clear_disabled = 0x7f020025;
    public static final int abs__ic_clear_holo_light = 0x7f020026;
    public static final int abs__ic_clear_normal = 0x7f020027;
    public static final int abs__ic_clear_search_api_disabled_holo_light = 0x7f020028;
    public static final int abs__ic_clear_search_api_holo_light = 0x7f020029;
    public static final int abs__ic_go = 0x7f02002a;
    public static final int abs__ic_go_search_api_holo_light = 0x7f02002b;
    public static final int abs__ic_menu_moreoverflow_holo_dark = 0x7f02002c;
    public static final int abs__ic_menu_moreoverflow_holo_light = 0x7f02002d;
    public static final int abs__ic_menu_moreoverflow_normal_holo_dark = 0x7f02002e;
    public static final int abs__ic_menu_moreoverflow_normal_holo_light = 0x7f02002f;
    public static final int abs__ic_menu_share_holo_dark = 0x7f020030;
    public static final int abs__ic_menu_share_holo_light = 0x7f020031;
    public static final int abs__ic_search = 0x7f020032;
    public static final int abs__ic_search_api_holo_light = 0x7f020033;
    public static final int abs__ic_voice_search = 0x7f020034;
    public static final int abs__ic_voice_search_api_holo_light = 0x7f020035;
    public static final int abs__item_background_holo_dark = 0x7f020036;
    public static final int abs__item_background_holo_light = 0x7f020037;
    public static final int abs__list_activated_holo = 0x7f020038;
    public static final int abs__list_divider_holo_dark = 0x7f020039;
    public static final int abs__list_divider_holo_light = 0x7f02003a;
    public static final int abs__list_focused_holo = 0x7f02003b;
    public static final int abs__list_longpressed_holo = 0x7f02003c;
    public static final int abs__list_pressed_holo_dark = 0x7f02003d;
    public static final int abs__list_pressed_holo_light = 0x7f02003e;
    public static final int abs__list_selector_background_transition_holo_dark = 0x7f02003f;
    public static final int abs__list_selector_background_transition_holo_light = 0x7f020040;
    public static final int abs__list_selector_disabled_holo_dark = 0x7f020041;
    public static final int abs__list_selector_disabled_holo_light = 0x7f020042;
    public static final int abs__list_selector_holo_dark = 0x7f020043;
    public static final int abs__list_selector_holo_light = 0x7f020044;
    public static final int abs__menu_dropdown_panel_holo_dark = 0x7f020045;
    public static final int abs__menu_dropdown_panel_holo_light = 0x7f020046;
    public static final int abs__progress_bg_holo_dark = 0x7f020047;
    public static final int abs__progress_bg_holo_light = 0x7f020048;
    public static final int abs__progress_horizontal_holo_dark = 0x7f020049;
    public static final int abs__progress_horizontal_holo_light = 0x7f02004a;
    public static final int abs__progress_medium_holo = 0x7f02004b;
    public static final int abs__progress_primary_holo_dark = 0x7f02004c;
    public static final int abs__progress_primary_holo_light = 0x7f02004d;
    public static final int abs__progress_secondary_holo_dark = 0x7f02004e;
    public static final int abs__progress_secondary_holo_light = 0x7f02004f;
    public static final int abs__search_dropdown_dark = 0x7f020050;
    public static final int abs__search_dropdown_light = 0x7f020051;
    public static final int abs__spinner_48_inner_holo = 0x7f020052;
    public static final int abs__spinner_48_outer_holo = 0x7f020053;
    public static final int abs__spinner_ab_default_holo_dark = 0x7f020054;
    public static final int abs__spinner_ab_default_holo_light = 0x7f020055;
    public static final int abs__spinner_ab_disabled_holo_dark = 0x7f020056;
    public static final int abs__spinner_ab_disabled_holo_light = 0x7f020057;
    public static final int abs__spinner_ab_focused_holo_dark = 0x7f020058;
    public static final int abs__spinner_ab_focused_holo_light = 0x7f020059;
    public static final int abs__spinner_ab_holo_dark = 0x7f02005a;
    public static final int abs__spinner_ab_holo_light = 0x7f02005b;
    public static final int abs__spinner_ab_pressed_holo_dark = 0x7f02005c;
    public static final int abs__spinner_ab_pressed_holo_light = 0x7f02005d;
    public static final int abs__tab_indicator_ab_holo = 0x7f02005e;
    public static final int abs__tab_selected_focused_holo = 0x7f02005f;
    public static final int abs__tab_selected_holo = 0x7f020060;
    public static final int abs__tab_selected_pressed_holo = 0x7f020061;
    public static final int abs__tab_unselected_pressed_holo = 0x7f020062;
    public static final int abs__textfield_search_default_holo_dark = 0x7f020063;
    public static final int abs__textfield_search_default_holo_light = 0x7f020064;
    public static final int abs__textfield_search_right_default_holo_dark = 0x7f020065;
    public static final int abs__textfield_search_right_default_holo_light = 0x7f020066;
    public static final int abs__textfield_search_right_selected_holo_dark = 0x7f020067;
    public static final int abs__textfield_search_right_selected_holo_light = 0x7f020068;
    public static final int abs__textfield_search_selected_holo_dark = 0x7f020069;
    public static final int abs__textfield_search_selected_holo_light = 0x7f02006a;
    public static final int abs__textfield_searchview_holo_dark = 0x7f02006b;
    public static final int abs__textfield_searchview_holo_light = 0x7f02006c;
    public static final int abs__textfield_searchview_right_holo_dark = 0x7f02006d;
    public static final int abs__textfield_searchview_right_holo_light = 0x7f02006e;

    public ()
    {
    }
}
