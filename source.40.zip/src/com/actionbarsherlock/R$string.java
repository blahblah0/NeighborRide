// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__action_bar_home_description = 0x7f060022;
    public static final int abs__action_bar_up_description = 0x7f060023;
    public static final int abs__action_menu_overflow_description = 0x7f060024;
    public static final int abs__action_mode_done = 0x7f060025;
    public static final int abs__activity_chooser_view_dialog_title_default = 0x7f060027;
    public static final int abs__activity_chooser_view_see_all = 0x7f060026;
    public static final int abs__activitychooserview_choose_application = 0x7f060029;
    public static final int abs__searchview_description_clear = 0x7f06002e;
    public static final int abs__searchview_description_query = 0x7f06002d;
    public static final int abs__searchview_description_search = 0x7f06002c;
    public static final int abs__searchview_description_submit = 0x7f06002f;
    public static final int abs__searchview_description_voice = 0x7f060030;
    public static final int abs__share_action_provider_share_with = 0x7f060028;
    public static final int abs__shareactionprovider_share_with = 0x7f06002a;
    public static final int abs__shareactionprovider_share_with_application = 0x7f06002b;

    public ()
    {
    }
}
