// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.widget;


// Referenced classes of package com.actionbarsherlock.widget:
//            SearchView

class this._cls0
    implements android.view.ver.OnGlobalLayoutListener
{

    final SearchView this$0;

    public void onGlobalLayout()
    {
        SearchView.access$400(SearchView.this);
    }

    utListener()
    {
        this$0 = SearchView.this;
        super();
    }
}
