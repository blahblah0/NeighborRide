// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.widget;

import android.view.View;

// Referenced classes of package com.actionbarsherlock.widget:
//            SearchView

class this._cls0
    implements android.view.istener
{

    final SearchView this$0;

    public void onClick(View view)
    {
        if (view == SearchView.access$500(SearchView.this))
        {
            SearchView.access$600(SearchView.this);
        } else
        {
            if (view == SearchView.access$700(SearchView.this))
            {
                SearchView.access$800(SearchView.this);
                return;
            }
            if (view == SearchView.access$900(SearchView.this))
            {
                SearchView.access$1000(SearchView.this);
                return;
            }
            if (view == SearchView.access$1100(SearchView.this))
            {
                SearchView.access$1200(SearchView.this);
                return;
            }
            if (view == SearchView.access$1300(SearchView.this))
            {
                SearchView.access$1400(SearchView.this);
                return;
            }
        }
    }

    ()
    {
        this$0 = SearchView.this;
        super();
    }
}
