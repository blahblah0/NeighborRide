// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.widget;


// Referenced classes of package com.actionbarsherlock.widget:
//            ActivityChooserModel

class this._cls1
    implements Runnable
{

    final is._cls0 this$1;

    public void run()
    {
        ActivityChooserModel.access$800(_fld0);
        ActivityChooserModel.access$900(_fld0);
    }

    ()
    {
        this$1 = this._cls1.this;
        super();
    }
}
