// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__background_holo_dark = 0x7f070017;
    public static final int abs__background_holo_light = 0x7f070018;
    public static final int abs__bright_foreground_disabled_holo_dark = 0x7f07001b;
    public static final int abs__bright_foreground_disabled_holo_light = 0x7f07001c;
    public static final int abs__bright_foreground_holo_dark = 0x7f070019;
    public static final int abs__bright_foreground_holo_light = 0x7f07001a;
    public static final int abs__bright_foreground_inverse_holo_dark = 0x7f07001d;
    public static final int abs__bright_foreground_inverse_holo_light = 0x7f07001e;
    public static final int abs__holo_blue_light = 0x7f07001f;
    public static final int abs__primary_text_disable_only_holo_dark = 0x7f070027;
    public static final int abs__primary_text_disable_only_holo_light = 0x7f070028;
    public static final int abs__primary_text_holo_dark = 0x7f070029;
    public static final int abs__primary_text_holo_light = 0x7f07002a;

    public ()
    {
    }
}
