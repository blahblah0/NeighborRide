// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.internal;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public final class ResourcesCompat
{

    private ResourcesCompat()
    {
    }

    public static boolean getResources_getBoolean(Context context, int i)
    {
        if (android.os.Build.VERSION.SDK_INT >= 13)
        {
            return context.getResources().getBoolean(i);
        }
        context = context.getResources().getDisplayMetrics();
        float f1 = (float)((DisplayMetrics) (context)).widthPixels / ((DisplayMetrics) (context)).density;
        float f2 = (float)((DisplayMetrics) (context)).heightPixels / ((DisplayMetrics) (context)).density;
        float f = f2;
        if (f1 < f2)
        {
            f = f1;
        }
        if (i == com.actionbarsherlock.R.bool.abs__action_bar_embed_tabs)
        {
            return f1 >= 480F;
        }
        if (i == com.actionbarsherlock.R.bool.abs__split_action_bar_is_narrow)
        {
            return f1 < 480F;
        }
        if (i == com.actionbarsherlock.R.bool.abs__action_bar_expanded_action_views_exclusive)
        {
            return f < 600F;
        }
        if (i == com.actionbarsherlock.R.bool.abs__config_allowActionMenuItemTextWithIcon)
        {
            return f1 >= 480F;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder("Unknown boolean resource ID ")).append(i).toString());
        }
    }

    public static int getResources_getInteger(Context context, int i)
    {
        if (android.os.Build.VERSION.SDK_INT >= 13)
        {
            return context.getResources().getInteger(i);
        }
        context = context.getResources().getDisplayMetrics();
        float f = (float)((DisplayMetrics) (context)).widthPixels / ((DisplayMetrics) (context)).density;
        if (i == com.actionbarsherlock.R.integer.abs__max_action_buttons)
        {
            if (f >= 600F)
            {
                return 5;
            }
            if (f >= 500F)
            {
                return 4;
            }
            return f < 360F ? 2 : 3;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder("Unknown integer resource ID ")).append(i).toString());
        }
    }
}
