// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.internal.view;


// Referenced classes of package com.actionbarsherlock.internal.view:
//            View_OnAttachStateChangeListener

public interface View_HasStateListenerSupport
{

    public abstract void addOnAttachStateChangeListener(View_OnAttachStateChangeListener view_onattachstatechangelistener);

    public abstract void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener view_onattachstatechangelistener);
}
