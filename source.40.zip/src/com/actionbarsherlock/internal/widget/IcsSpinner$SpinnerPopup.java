// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.internal.widget;

import android.widget.ListAdapter;

interface 
{

    public abstract void dismiss();

    public abstract CharSequence getHintText();

    public abstract boolean isShowing();

    public abstract void setAdapter(ListAdapter listadapter);

    public abstract void setPromptText(CharSequence charsequence);

    public abstract void show();
}
