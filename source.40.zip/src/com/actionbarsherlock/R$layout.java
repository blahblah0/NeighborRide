// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__action_bar_home = 0x7f030002;
    public static final int abs__action_bar_tab = 0x7f030003;
    public static final int abs__action_bar_tab_bar_view = 0x7f030004;
    public static final int abs__action_bar_title_item = 0x7f030005;
    public static final int abs__action_menu_item_layout = 0x7f030006;
    public static final int abs__action_menu_layout = 0x7f030007;
    public static final int abs__action_mode_bar = 0x7f030008;
    public static final int abs__action_mode_close_item = 0x7f030009;
    public static final int abs__activity_chooser_view = 0x7f03000a;
    public static final int abs__activity_chooser_view_list_item = 0x7f03000b;
    public static final int abs__dialog_title_holo = 0x7f03000c;
    public static final int abs__list_menu_item_checkbox = 0x7f03000d;
    public static final int abs__list_menu_item_icon = 0x7f03000e;
    public static final int abs__list_menu_item_layout = 0x7f03000f;
    public static final int abs__list_menu_item_radio = 0x7f030010;
    public static final int abs__popup_menu_item_layout = 0x7f030011;
    public static final int abs__screen_action_bar = 0x7f030012;
    public static final int abs__screen_action_bar_overlay = 0x7f030013;
    public static final int abs__screen_simple = 0x7f030014;
    public static final int abs__screen_simple_overlay_action_mode = 0x7f030015;
    public static final int abs__search_dropdown_item_icons_2line = 0x7f030016;
    public static final int abs__search_view = 0x7f030017;
    public static final int abs__simple_dropdown_hint = 0x7f030018;
    public static final int sherlock_spinner_dropdown_item = 0x7f030023;
    public static final int sherlock_spinner_item = 0x7f030024;

    public ()
    {
    }
}
