// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int SherlockActionBar[] = {
        0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d, 0x7f01003e, 0x7f010081, 0x7f010082, 0x7f010083, 0x7f010084, 
        0x7f010085, 0x7f010086, 0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 0x7f01008d
    };
    public static final int SherlockActionBar_background = 2;
    public static final int SherlockActionBar_backgroundSplit = 3;
    public static final int SherlockActionBar_backgroundStacked = 12;
    public static final int SherlockActionBar_customNavigationLayout = 13;
    public static final int SherlockActionBar_displayOptions = 7;
    public static final int SherlockActionBar_divider = 5;
    public static final int SherlockActionBar_height = 4;
    public static final int SherlockActionBar_homeLayout = 14;
    public static final int SherlockActionBar_icon = 10;
    public static final int SherlockActionBar_indeterminateProgressStyle = 16;
    public static final int SherlockActionBar_itemPadding = 18;
    public static final int SherlockActionBar_logo = 11;
    public static final int SherlockActionBar_navigationMode = 6;
    public static final int SherlockActionBar_progressBarPadding = 17;
    public static final int SherlockActionBar_progressBarStyle = 15;
    public static final int SherlockActionBar_subtitle = 9;
    public static final int SherlockActionBar_subtitleTextStyle = 1;
    public static final int SherlockActionBar_title = 8;
    public static final int SherlockActionBar_titleTextStyle = 0;
    public static final int SherlockActionMenuItemView[] = {
        0x101013f
    };
    public static final int SherlockActionMenuItemView_android_minWidth = 0;
    public static final int SherlockActionMode[] = {
        0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d
    };
    public static final int SherlockActionMode_background = 2;
    public static final int SherlockActionMode_backgroundSplit = 3;
    public static final int SherlockActionMode_height = 4;
    public static final int SherlockActionMode_subtitleTextStyle = 1;
    public static final int SherlockActionMode_titleTextStyle = 0;
    public static final int SherlockActivityChooserView[] = {
        0x10100d4, 0x7f010096, 0x7f010097
    };
    public static final int SherlockActivityChooserView_android_background = 0;
    public static final int SherlockActivityChooserView_expandActivityOverflowButtonDrawable = 2;
    public static final int SherlockActivityChooserView_initialActivityCount = 1;
    public static final int SherlockMenuGroup[] = {
        0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
    };
    public static final int SherlockMenuGroup_android_checkableBehavior = 5;
    public static final int SherlockMenuGroup_android_enabled = 0;
    public static final int SherlockMenuGroup_android_id = 1;
    public static final int SherlockMenuGroup_android_menuCategory = 3;
    public static final int SherlockMenuGroup_android_orderInCategory = 4;
    public static final int SherlockMenuGroup_android_visible = 2;
    public static final int SherlockMenuItem[] = {
        0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
        0x10101e4, 0x10101e5, 0x101026f, 0x10102d9, 0x10102fb, 0x10102fc, 0x1010389
    };
    public static final int SherlockMenuItem_android_actionLayout = 14;
    public static final int SherlockMenuItem_android_actionProviderClass = 16;
    public static final int SherlockMenuItem_android_actionViewClass = 15;
    public static final int SherlockMenuItem_android_alphabeticShortcut = 9;
    public static final int SherlockMenuItem_android_checkable = 11;
    public static final int SherlockMenuItem_android_checked = 3;
    public static final int SherlockMenuItem_android_enabled = 1;
    public static final int SherlockMenuItem_android_icon = 0;
    public static final int SherlockMenuItem_android_id = 2;
    public static final int SherlockMenuItem_android_menuCategory = 5;
    public static final int SherlockMenuItem_android_numericShortcut = 10;
    public static final int SherlockMenuItem_android_onClick = 12;
    public static final int SherlockMenuItem_android_orderInCategory = 6;
    public static final int SherlockMenuItem_android_showAsAction = 13;
    public static final int SherlockMenuItem_android_title = 7;
    public static final int SherlockMenuItem_android_titleCondensed = 8;
    public static final int SherlockMenuItem_android_visible = 4;
    public static final int SherlockMenuView[] = {
        0x7f01008e, 0x7f01008f, 0x7f010090, 0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095
    };
    public static final int SherlockMenuView_headerBackground = 3;
    public static final int SherlockMenuView_horizontalDivider = 1;
    public static final int SherlockMenuView_itemBackground = 4;
    public static final int SherlockMenuView_itemIconDisabledAlpha = 6;
    public static final int SherlockMenuView_itemTextAppearance = 0;
    public static final int SherlockMenuView_preserveIconSpacing = 7;
    public static final int SherlockMenuView_verticalDivider = 2;
    public static final int SherlockMenuView_windowAnimationStyle = 5;
    public static final int SherlockSearchView[] = {
        0x101011f, 0x1010220, 0x1010264, 0x7f010098, 0x7f010099
    };
    public static final int SherlockSearchView_android_imeOptions = 2;
    public static final int SherlockSearchView_android_inputType = 1;
    public static final int SherlockSearchView_android_maxWidth = 0;
    public static final int SherlockSearchView_iconifiedByDefault = 3;
    public static final int SherlockSearchView_queryHint = 4;
    public static final int SherlockSpinner[] = {
        0x10100af, 0x1010175, 0x1010176, 0x101017b, 0x1010262, 0x10102ac, 0x10102ad, 0x1160051
    };
    public static final int SherlockSpinner_android_dropDownHorizontalOffset = 5;
    public static final int SherlockSpinner_android_dropDownSelector = 1;
    public static final int SherlockSpinner_android_dropDownVerticalOffset = 6;
    public static final int SherlockSpinner_android_dropDownWidth = 4;
    public static final int SherlockSpinner_android_gravity = 0;
    public static final int SherlockSpinner_android_popupBackground = 2;
    public static final int SherlockSpinner_android_popupPromptView = 7;
    public static final int SherlockSpinner_android_prompt = 3;
    public static final int SherlockTheme[] = {
        0x1010057, 0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 0x7f010047, 
        0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 0x7f010051, 
        0x7f010052, 0x7f010053, 0x7f010054, 0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059, 0x7f01005a, 0x7f01005b, 
        0x7f01005c, 0x7f01005d, 0x7f01005e, 0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 0x7f010065, 
        0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 0x7f01006f, 
        0x7f010070, 0x7f010071, 0x7f010072, 0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 0x7f010079, 
        0x7f01007a, 0x7f01007b, 0x7f01007c, 0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080
    };
    public static final int SherlockTheme_actionBarDivider = 9;
    public static final int SherlockTheme_actionBarItemBackground = 10;
    public static final int SherlockTheme_actionBarSize = 8;
    public static final int SherlockTheme_actionBarSplitStyle = 6;
    public static final int SherlockTheme_actionBarStyle = 5;
    public static final int SherlockTheme_actionBarTabBarStyle = 2;
    public static final int SherlockTheme_actionBarTabStyle = 1;
    public static final int SherlockTheme_actionBarTabTextStyle = 3;
    public static final int SherlockTheme_actionBarWidgetTheme = 7;
    public static final int SherlockTheme_actionButtonStyle = 53;
    public static final int SherlockTheme_actionDropDownStyle = 52;
    public static final int SherlockTheme_actionMenuTextAppearance = 11;
    public static final int SherlockTheme_actionMenuTextColor = 12;
    public static final int SherlockTheme_actionModeBackground = 15;
    public static final int SherlockTheme_actionModeCloseButtonStyle = 14;
    public static final int SherlockTheme_actionModeCloseDrawable = 17;
    public static final int SherlockTheme_actionModePopupWindowStyle = 19;
    public static final int SherlockTheme_actionModeShareDrawable = 18;
    public static final int SherlockTheme_actionModeSplitBackground = 16;
    public static final int SherlockTheme_actionModeStyle = 13;
    public static final int SherlockTheme_actionOverflowButtonStyle = 4;
    public static final int SherlockTheme_actionSpinnerItemStyle = 58;
    public static final int SherlockTheme_activatedBackgroundIndicator = 66;
    public static final int SherlockTheme_activityChooserViewStyle = 65;
    public static final int SherlockTheme_android_windowIsFloating = 0;
    public static final int SherlockTheme_buttonStyleSmall = 20;
    public static final int SherlockTheme_dividerVertical = 51;
    public static final int SherlockTheme_dropDownListViewStyle = 55;
    public static final int SherlockTheme_dropdownListPreferredItemHeight = 57;
    public static final int SherlockTheme_homeAsUpIndicator = 54;
    public static final int SherlockTheme_listPopupWindowStyle = 64;
    public static final int SherlockTheme_listPreferredItemHeightSmall = 45;
    public static final int SherlockTheme_listPreferredItemPaddingLeft = 46;
    public static final int SherlockTheme_listPreferredItemPaddingRight = 47;
    public static final int SherlockTheme_popupMenuStyle = 56;
    public static final int SherlockTheme_searchAutoCompleteTextView = 31;
    public static final int SherlockTheme_searchDropdownBackground = 32;
    public static final int SherlockTheme_searchResultListItemHeight = 42;
    public static final int SherlockTheme_searchViewCloseIcon = 33;
    public static final int SherlockTheme_searchViewEditQuery = 37;
    public static final int SherlockTheme_searchViewEditQueryBackground = 38;
    public static final int SherlockTheme_searchViewGoIcon = 34;
    public static final int SherlockTheme_searchViewSearchIcon = 35;
    public static final int SherlockTheme_searchViewTextField = 39;
    public static final int SherlockTheme_searchViewTextFieldRight = 40;
    public static final int SherlockTheme_searchViewVoiceIcon = 36;
    public static final int SherlockTheme_selectableItemBackground = 21;
    public static final int SherlockTheme_spinnerDropDownItemStyle = 30;
    public static final int SherlockTheme_spinnerItemStyle = 29;
    public static final int SherlockTheme_textAppearanceLargePopupMenu = 23;
    public static final int SherlockTheme_textAppearanceListItemSmall = 48;
    public static final int SherlockTheme_textAppearanceSearchResultSubtitle = 44;
    public static final int SherlockTheme_textAppearanceSearchResultTitle = 43;
    public static final int SherlockTheme_textAppearanceSmall = 25;
    public static final int SherlockTheme_textAppearanceSmallPopupMenu = 24;
    public static final int SherlockTheme_textColorPrimary = 26;
    public static final int SherlockTheme_textColorPrimaryDisableOnly = 27;
    public static final int SherlockTheme_textColorPrimaryInverse = 28;
    public static final int SherlockTheme_textColorSearchUrl = 41;
    public static final int SherlockTheme_windowActionBar = 60;
    public static final int SherlockTheme_windowActionBarOverlay = 61;
    public static final int SherlockTheme_windowActionModeOverlay = 62;
    public static final int SherlockTheme_windowContentOverlay = 22;
    public static final int SherlockTheme_windowMinWidthMajor = 49;
    public static final int SherlockTheme_windowMinWidthMinor = 50;
    public static final int SherlockTheme_windowNoTitle = 59;
    public static final int SherlockTheme_windowSplitActionBar = 63;
    public static final int SherlockView[] = {
        0x10100da
    };
    public static final int SherlockView_android_focusable = 0;


    public ()
    {
    }
}
