// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock;


public final class 
{

    public static final int abs__action_bar_embed_tabs = 0x7f0b0000;
    public static final int abs__action_bar_expanded_action_views_exclusive = 0x7f0b0002;
    public static final int abs__config_actionMenuItemAllCaps = 0x7f0b0004;
    public static final int abs__config_allowActionMenuItemTextWithIcon = 0x7f0b0005;
    public static final int abs__config_showMenuShortcutsWhenKeyboardPresent = 0x7f0b0003;
    public static final int abs__split_action_bar_is_narrow = 0x7f0b0001;

    public ()
    {
    }
}
