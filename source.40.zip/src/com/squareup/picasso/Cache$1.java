// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.squareup.picasso;

import android.graphics.Bitmap;

// Referenced classes of package com.squareup.picasso:
//            Cache

final class 
    implements Cache
{

    public final void clear()
    {
    }

    public final void clearKeyUri(String s)
    {
    }

    public final Bitmap get(String s)
    {
        return null;
    }

    public final int maxSize()
    {
        return 0;
    }

    public final void set(String s, Bitmap bitmap)
    {
    }

    public final int size()
    {
        return 0;
    }

    ()
    {
    }
}
